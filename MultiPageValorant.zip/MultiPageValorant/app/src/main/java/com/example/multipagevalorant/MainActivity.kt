package com.example.multipagevalorant

import android.content.Intent
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private val agents = arrayOf("Jett", "Phoenix", "Sage")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.agentListView)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, agents)
        listView.adapter = adapter

        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            val intent = Intent(this, AgentDetailActivity::class.java)
            intent.putExtra("agentName", agents[position])
            startActivity(intent)

            findViewById<Button>(R.id.aboutButton).setOnClickListener {
                startActivity(Intent(this, AboutActivity::class.java))
            }

        }
    }
}




