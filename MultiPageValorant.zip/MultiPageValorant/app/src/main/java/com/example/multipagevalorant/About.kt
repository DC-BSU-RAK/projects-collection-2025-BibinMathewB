package com.example.multipagevalorant

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.multipagevalorant.R

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
    }
}
