package com.example.multipagevalorant

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.multipagevalorant.R

class AgentDetailActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var textView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agent_detail)

        imageView = findViewById(R.id.agentname)
        textView = findViewById(R.id.agentInfo)

        val agentName = intent.getStringExtra("agentName")

        when (agentName) {
            "Jett" -> {
                imageView.setImageResource(R.drawable.jett)
                textView.text = "Jett is an agile fighter who prioritizes mobility. Abilities: Updraft, Tailwind, Cloudburst." +
                        "Jett is a nimble and elusive Radiant from South Korea, renowned for her unmatched agility and swift combat movements. Her personality is sharp and sarcastic, often taunting opponents and teammates alike. She believes in outplaying her enemies with style and speed rather than brute force."
            }
            "Phoenix" -> {
                imageView.setImageResource(R.drawable.phx)
                textView.text = "Phoenix uses fire-based abilities. Abilities: Curveball, Blaze, Hot Hands." +
                        "Phoenix is a fiery and confident Radiant from London, known for his brash attitude and aggressive combat style. His powers center around manipulating fire, allowing him to curve blinding flashes, create walls of flame, and even heal himself or rise from the dead."
            }
            "Sage" -> {
                imageView.setImageResource(R.drawable.sageval)
                textView.text = "Sage is a support agent with healing powers. Abilities: Barrier Orb, Healing Orb, Resurrection." +
                        "Sage is a Radiant monk from China, serving as the Valorant Protocol’s primary healer and one of its moral anchors. Calm, composed, and deeply spiritual, Sage carries herself with grace and wisdom. She believes in protecting life and maintaining balance, even amidst chaos."
            }
        }
    }
}
