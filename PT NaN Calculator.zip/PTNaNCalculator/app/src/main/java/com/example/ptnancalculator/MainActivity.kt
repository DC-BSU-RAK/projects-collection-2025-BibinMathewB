package com.example.ptnancalculator

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView
    private val selectedElements = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display)

        showInstructionsDialog()

        val elements = listOf(
            Pair(R.id.btnH, "H"),
            Pair(R.id.btnO, "O"),
            Pair(R.id.btnNa, "Na"),
            Pair(R.id.btnCl, "Cl"),
            Pair(R.id.btnC, "C"),
            Pair(R.id.btnN, "N")
        )

        for ((id, symbol) in elements) {
            findViewById<Button>(id).setOnClickListener {
                selectedElements.add(symbol)
                display.text = "Selected: ${selectedElements.joinToString("-")}"
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            selectedElements.clear()
            display.text = "Result: NaN"
        }

        findViewById<Button>(R.id.btnCalc).setOnClickListener {
            val result = "NaN (" + selectedElements.joinToString("") + ")"
            display.text = "Result: $result"
        }
    }

    private fun showInstructionsDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Welcome to NaN Calculator")
        builder.setMessage(
            "Instructions:\n\n" +
                    "- This calculator uses periodic table elements instead of numbers.\n" +
                    "- Tap on elements to form combinations.\n" +
                    "- Press CALC to see a NaN-style result.\n" +
                    "- Press CLEAR to reset your selection.\n\n" +
                    "Have fun exploring chemistry—without numbers!"
        )
        builder.setPositiveButton("Got it") { dialog, _ ->
            dialog.dismiss()
        }
        builder.setCancelable(false)
        builder.show()
    }
}
